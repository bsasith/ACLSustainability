<?php
require_once __DIR__ . '/../auth.php';
require_login();

/* HEAD OFFICE USER ONLY */
if (!isset($_SESSION['utype']) || $_SESSION['utype'] !== 'houser') {
    logout();
  //  header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ACL Cables PLC - Head Office Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="../styles/indexstyle.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>

<!-- ===== TOP BAR (UNCHANGED STYLE) ===== -->
<div class="topbar">
    <h1 class="topbar-text">Welcome <?php echo htmlspecialchars(current_username()); ?></h1>
    <a href="../logout.php"><h1 class="topbar-logout">Logout &nbsp;</h1></a>
    <h1 class="topbar-username"><?php echo htmlspecialchars(current_username()); ?>&nbsp;</h1>
</div>

<!-- ===== DASHBOARD CONTENT ===== -->
<div class="container-fluid mt-4">

    <!-- 1. Electricity Consumption -->
    <div class="dashboard-row">
        <div class="dashboard-left">
            <i class="bi bi-lightning-charge-fill"></i>
            <span>ACL Cables PLC - H/O &amp; Warehouses Electricity Consumption</span>
        </div>
        <div class="dashboard-actions">
            <a href="ho_electricity_acl_cables.php" class="btn btn-success btn-sm">Enter</a>
            <a href="ho_electricity_acl_cables_view_edit.php" class="btn btn-warning btn-sm">Edit / View</a>
            <a href="ho_electricity_acl_cables_download.php" class="btn btn-primary btn-sm">Download</a>
        </div>
    </div>

    <!-- 2. Senior Managers Fuel Consumption -->
    <div class="dashboard-row">
        <div class="dashboard-left">
            <i class="bi bi-fuel-pump-fill"></i>
            <span>ACL Cables PLC - H/O Senior Managers Fuel Consumption</span>
        </div>
        <div class="dashboard-actions">
            <a href="ho_fuel_senior_managers_acl_cables.php" class="btn btn-success btn-sm">Enter</a>
            <a href="ho_fuel_senior_managers_acl_cables_view_edit.php" class="btn btn-warning btn-sm">Edit / View</a>
            <a href="ho_fuel_senior_managers_acl_cables_download.php" class="btn btn-primary btn-sm">Download</a>
        </div>
    </div>

    <!-- 3. Solar Energy Generation -->
    <div class="dashboard-row">
        <div class="dashboard-left">
            <i class="bi bi-sun-fill"></i>
            <span>ACL Cables PLC - H/O Energy Generation - Solar</span>
        </div>
        <div class="dashboard-actions">
            <a href="ho_solar_generation_acl_cables.php" class="btn btn-success btn-sm">Enter</a>
            <a href="ho_solar_generation_acl_cables_view_edit.php" class="btn btn-warning btn-sm">Edit / View</a>
            <a href="ho_solar_generation_acl_cables_download.php" class="btn btn-primary btn-sm">Download</a>
        </div>
    </div>

    <!-- 4. Distribution Fuel Consumption -->
    <div class="dashboard-row">
        <div class="dashboard-left">
            <i class="bi bi-truck-front-fill"></i>
            <span>ACL Cables PLC - H/O Distribution Fuel Consumption</span>
        </div>
        <div class="dashboard-actions">
            <a href="ho_fuel_distribution_acl_cables.php" class="btn btn-success btn-sm">Enter</a>
            <a href="ho_fuel_distribution_acl_cables_view_edit.php" class="btn btn-warning btn-sm">Edit / View</a>
            <a href="ho_fuel_distribution_acl_cables_download.php" class="btn btn-primary btn-sm">Download</a>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
