<?php
require_once __DIR__ . '/../auth.php';
require_login();

if (!isset($_SESSION['utype']) || $_SESSION['utype'] !== 'acuser') {
    logout();
    header('Location: login.php');
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = db();

$monthsMap = [
    'January'=>1,'February'=>2,'March'=>3,'April'=>4,'May'=>5,'June'=>6,
    'July'=>7,'August'=>8,'September'=>9,'October'=>10,'November'=>11,'December'=>12
];
$monthsRev = array_flip($monthsMap);

function monthCaseSql($col = 'report_month') {
    return "CASE $col
        WHEN 'January' THEN 1
        WHEN 'February' THEN 2
        WHEN 'March' THEN 3
        WHEN 'April' THEN 4
        WHEN 'May' THEN 5
        WHEN 'June' THEN 6
        WHEN 'July' THEN 7
        WHEN 'August' THEN 8
        WHEN 'September' THEN 9
        WHEN 'October' THEN 10
        WHEN 'November' THEN 11
        WHEN 'December' THEN 12
        ELSE 0 END";
}

/**
 * KPI mapping
 */
$KPI = [
    'diesel_boilers_acl_cables' => [
        'title' => 'a) Monthly Diesel Consumption – Steam Boilers',
        'meta'  => 'ACL Cables PLC',
        'value_col' => 'diesel_litres',
        'unit' => 'Litres',
        'icon' => 'bi-fire'
    ],
    'diesel_forklifts_acl_cables' => [
        'title' => 'b) Monthly Diesel Consumption – Forklifts',
        'meta'  => 'ACL Cables PLC',
        'value_col' => 'diesel_litres',
        'unit' => 'Litres',
        'icon' => 'bi-truck-flatbed'
    ],
    'furnace_oil_acl_metals_alloys' => [
        'title' => 'b) Monthly Furnace Oil Consumption',
        'meta'  => 'ACL Metals & Alloys',
        'value_col' => 'furnace_oil_litres',
        'unit' => 'Litres',
        'icon' => 'bi-droplet-fill'
    ],
    'diesel_transport_logistics_acl_complex' => [
        'title' => 'c) Monthly Diesel Consumption – Transportation & Logistics',
        'meta'  => 'ACL Factory Complex',
        'value_col' => 'diesel_litres',
        'unit' => 'Litres',
        'icon' => 'bi-truck'
    ],
    'diesel_senior_vehicles_acl_complex' => [
        'title' => 'd) Monthly Diesel Consumption – Senior Executive Vehicles',
        'meta'  => 'ACL Cables Factory Complex',
        'value_col' => 'diesel_litres',
        'unit' => 'Litres',
        'icon' => 'bi-car-front-fill'
    ],
];

// -------------------------
// Read filters (GET)
// -------------------------
$startPeriod = $_GET['start'] ?? ''; // YYYY-MM
$endPeriod   = $_GET['end'] ?? '';   // YYYY-MM
$tableSel    = $_GET['kpi'] ?? '';   // table name OR "ALL"

$data = [];
$errorMsg = '';

function parsePeriod($p) {
    if (!preg_match('/^\d{4}-\d{2}$/', $p)) return null;
    $y = (int)substr($p, 0, 4);
    $m = (int)substr($p, 5, 2);
    if ($y < 2000 || $m < 1 || $m > 12) return null;
    return [$y, $m];
}

$sp = $startPeriod ? parsePeriod($startPeriod) : null;
$ep = $endPeriod ? parsePeriod($endPeriod) : null;

// Default: current month
if (!$sp) {
    $sp = [(int)date('Y'), (int)date('n')];
    $startPeriod = sprintf('%04d-%02d', $sp[0], $sp[1]);
}
if (!$ep) {
    $ep = [(int)date('Y'), (int)date('n')];
    $endPeriod = sprintf('%04d-%02d', $ep[0], $ep[1]);
}

$startKey = $sp[0]*100 + $sp[1];
$endKey   = $ep[0]*100 + $ep[1];
if ($startKey > $endKey) {
    [$sp, $ep] = [$ep, $sp];
    [$startKey, $endKey] = [$endKey, $startKey];
    $startPeriod = sprintf('%04d-%02d', $sp[0], $sp[1]);
    $endPeriod   = sprintf('%04d-%02d', $ep[0], $ep[1]);
}

$isSameMonth = ($startKey === $endKey);

// Selection rules
if (!$isSameMonth) {
    if ($tableSel === '' || $tableSel === 'ALL') {
        $tableSel = array_key_first($KPI);
    }
} else {
    if ($tableSel === '') $tableSel = 'ALL';
}

// -------------------------
// Query builder
// -------------------------
try {
    if ($isSameMonth && $tableSel === 'ALL') {

        $year = $sp[0];
        $monthNo = $sp[1];
        $monthName = $monthsRev[$monthNo] ?? '';

        $parts = [];
        foreach ($KPI as $t => $cfg) {
            $valCol = $cfg['value_col'];
            $title  = $conn->real_escape_string($cfg['title']);
            $meta   = $conn->real_escape_string($cfg['meta']);
            $unit   = $conn->real_escape_string($cfg['unit']);

            $parts[] = "
                SELECT
                    id,
                    '$t' AS kpi_table,
                    '$title' AS kpi_title,
                    '$meta' AS kpi_meta,
                    '$unit' AS kpi_unit,
                    report_year,
                    report_month,
                    $valCol AS kpi_value,
                    created_by,
                    created_at
                FROM $t
                WHERE report_year = ? AND report_month = ?
            ";
        }

        $sql = implode(" UNION ALL ", $parts) . " ORDER BY created_at DESC, kpi_title ASC";
        $stmt = $conn->prepare($sql);

        $types = str_repeat("is", count($KPI));
        $params = [];
        for ($i=0; $i<count($KPI); $i++){
            $params[] = $year;
            $params[] = $monthName;
        }

        $bind = [];
        $bind[] = $types;
        foreach ($params as $k => $v) $bind[] = &$params[$k];
        call_user_func_array([$stmt, 'bind_param'], $bind);

        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) $data[] = $r;
        $stmt->close();

    } else {

        if (!isset($KPI[$tableSel])) {
            $errorMsg = "Invalid KPI selection.";
        } else {
            $cfg = $KPI[$tableSel];
            $valCol = $cfg['value_col'];

            $case = monthCaseSql('report_month');
            $sql = "SELECT id, report_year, report_month, $valCol AS kpi_value, created_by, created_at
                    FROM $tableSel
                    WHERE (report_year * 100 + $case) BETWEEN ? AND ?
                    ORDER BY (report_year * 100 + $case) DESC, created_at DESC";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $startKey, $endKey);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) $data[] = $r;
            $stmt->close();
        }
    }
} catch (mysqli_sql_exception $e) {
    $errorMsg = "Database error: " . htmlspecialchars($e->getMessage());
}

// Header titles
$headerTitle = "KPI Results by Period";
$headerSub   = "Select a period (Month/Year). Newest records shown first.";
if ($isSameMonth && $tableSel === 'ALL') {
    $headerTitle = "All KPI Results (Selected Month)";
    $headerSub   = "Showing all KPIs for {$monthsRev[$sp[1]]} {$sp[0]} (newest first).";
} elseif (isset($KPI[$tableSel])) {
    $headerTitle = $KPI[$tableSel]['title'];
    $headerSub   = $KPI[$tableSel]['meta'] . " | Newest first";
}

// -------------------------
// Build totals + chart data (MONTH vs VALUE)
// - For chart, we aggregate by report_year + report_month (sum values)
// -------------------------
$totalLitres = 0.0;
$chartAgg = []; // key "YYYY-MM" => sum

foreach ($data as $r) {
    $val = isset($r['kpi_value']) ? (float)$r['kpi_value'] : 0.0;
    $totalLitres += $val;

    $mName = $r['report_month'] ?? '';
    $mNo = $monthsMap[$mName] ?? 0;
    $y = (int)($r['report_year'] ?? 0);
    if ($y > 0 && $mNo > 0) {
        $key = sprintf('%04d-%02d', $y, $mNo);
        if (!isset($chartAgg[$key])) $chartAgg[$key] = 0.0;
        $chartAgg[$key] += $val;
    }
}

// Sort chart by month ascending
ksort($chartAgg);

// Prepare arrays for JS
$chartLabels = array_keys($chartAgg);
$chartValues = array_values($chartAgg);

// Determine label for total card/unit
$totalLabel = "Total Consumption";
$totalUnit = "Litres";
if (!$errorMsg && !$isSameMonth && isset($KPI[$tableSel])) {
    $totalLabel = "Total for Selected Period";
    $totalUnit = $KPI[$tableSel]['unit'] ?? 'Litres';
} elseif (!$errorMsg && $isSameMonth && $tableSel === 'ALL') {
    $totalLabel = "Total (All KPIs - Selected Month)";
}

// -------------------------
// CSV Download (GET ?download=csv)
// -------------------------
if (isset($_GET['download']) && $_GET['download'] === 'csv' && empty($errorMsg)) {

    $fname = 'kpi_results_' . $startPeriod . '_to_' . $endPeriod;
    if ($isSameMonth && $tableSel === 'ALL') {
        $fname = 'kpi_all_' . $startPeriod;
    } elseif (isset($KPI[$tableSel])) {
        $fname = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $tableSel) . '_' . $startPeriod . '_to_' . $endPeriod;
    }
    $fname .= '.csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="'.$fname.'"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $out = fopen('php://output', 'w');

    if ($isSameMonth && $tableSel === 'ALL') {
        fputcsv($out, ['KPI', 'Company/Unit', 'Year', 'Month', 'Value', 'Entered By', 'Date Entered']);
        foreach ($data as $r) {
            $val = isset($r['kpi_value']) ? (float)$r['kpi_value'] : 0.0;
            fputcsv($out, [
                $r['kpi_title'] ?? '',
                ($r['kpi_meta'] ?? '') . (isset($r['kpi_unit']) ? (' | ' . $r['kpi_unit']) : ''),
                $r['report_year'] ?? '',
                $r['report_month'] ?? '',
                number_format($val, 2, '.', ''),
                $r['created_by'] ?? '',
                isset($r['created_at']) ? date('Y-m-d', strtotime($r['created_at'])) : ''
            ]);
        }
    } else {
        $title = $KPI[$tableSel]['title'] ?? 'KPI';
        $meta  = $KPI[$tableSel]['meta'] ?? '';
        $unit  = $KPI[$tableSel]['unit'] ?? '';

        fputcsv($out, ['KPI', 'Company/Unit', 'Year', 'Month', 'Value', 'Entered By', 'Date Entered']);
        foreach ($data as $r) {
            $val = isset($r['kpi_value']) ? (float)$r['kpi_value'] : 0.0;
            fputcsv($out, [
                $title,
                trim($meta . ($unit ? " | $unit" : '')),
                $r['report_year'] ?? '',
                $r['report_month'] ?? '',
                number_format($val, 2, '.', ''),
                $r['created_by'] ?? '',
                isset($r['created_at']) ? date('Y-m-d', strtotime($r['created_at'])) : ''
            ]);
        }
    }

    fclose($out);
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Period Results – AcUser</title>

<link rel="stylesheet" href="../styles/indexstyle.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Jockey+One&display=swap" rel="stylesheet">

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<style>
.content-wrap{
    max-width:1100px;
    margin:40px auto;
    padding:0 15px;
}
.header-card, .section-card{
    border:none;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,.08);
    overflow:hidden;
}
.header-card .card-body{
    background: linear-gradient(135deg, #f8fafc 0%, #ffffff 60%, #f0f9ff 100%);
}
.section-top{
    padding:18px 20px;
    border-bottom:1px solid #e5e7eb;
    background:#f8fafc;
}
.section-title{
    margin:0;
    font-family:"Jockey One", sans-serif;
    font-size:22px;
    color:#0f172a;
    display:flex;
    align-items:center;
    gap:10px;
}
.section-sub{
    margin-top:6px;
    color:#64748b;
    font-weight:600;
    font-size:.95rem;
}
.filter-row{
    display:flex;
    gap:12px;
    flex-wrap:wrap;
    align-items:end;
}
.filter-row .form-label{ font-weight:800; }
.btn-ghost{ border-radius:999px; }
.table thead th{
    background:#f8fafc;
    font-weight:800;
    color:#0f172a;
}
.kpi-chip{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:6px 10px;
    border-radius:999px;
    background:#f1f5f9;
    color:#0f172a;
    font-weight:800;
    font-size:.85rem;
}
.kpi-chip i{ color:#0f766e; }

/* Total Card */
.total-card{
    border-radius:16px;
    border:1px solid #e5e7eb;
    background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
    padding:16px 18px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
}
.total-left{
    display:flex;
    align-items:center;
    gap:12px;
}
.total-icon{
    width:44px; height:44px;
    border-radius:14px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#ecfeff;
    border:1px solid #cffafe;
    color:#0e7490;
    font-size:20px;
}
.total-title{
    font-weight:900;
    color:#0f172a;
}
.total-sub{
    color:#64748b;
    font-weight:700;
    font-size:.9rem;
}
.total-value{
    text-align:right;
}
.total-value .num{
    font-size:1.4rem;
    font-weight:900;
    color:#0f172a;
}
.total-value .unit{
    color:#64748b;
    font-weight:800;
    font-size:.9rem;
}

/* Chart Card */
.chart-wrap{
    border-radius:16px;
    border:1px solid #e5e7eb;
    background:#ffffff;
    padding:14px 16px 10px 16px;
}
.chart-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-bottom:8px;
}
.chart-title{
    font-weight:900;
    color:#0f172a;
}
.chart-note{
    color:#64748b;
    font-weight:700;
    font-size:.9rem;
}
</style>
</head>

<body>

<div class="topbar">
    <h1 class="topbar-text">Welcome <?php echo htmlspecialchars(current_username()); ?></h1>
    <a href="../logout.php"><h1 class="topbar-logout">Logout &nbsp;</h1></a>
    <h1 class="topbar-username"><?php echo htmlspecialchars(current_username()); ?>&nbsp;</h1>
</div>

<div class="content-wrap">

    <!-- Header Card -->
    <div class="card header-card mb-3">
        <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div class="d-flex align-items-start gap-2">
                <i class="bi bi-calendar2-range text-primary fs-5"></i>
                <div>
                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($headerTitle); ?></div>
                    <div class="text-muted fw-semibold"><?php echo htmlspecialchars($headerSub); ?></div>
                </div>
            </div>

            <a href="dashboard.php" class="btn btn-outline-primary btn-sm btn-ghost">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="card section-card mb-3">
        <div class="section-top">
            <h2 class="section-title">
                <i class="bi bi-funnel-fill text-primary"></i>
                Filter by Period
            </h2>
            <div class="section-sub">
                Choose start and end Month/Year. If both months are the same, you can select which KPI table to display (or show all).
            </div>
        </div>

        <div class="card-body">
            <form method="get" class="filter-row">

                <div>
                    <label class="form-label">Start (Month/Year)</label>
                    <input type="month" name="start" value="<?php echo htmlspecialchars($startPeriod); ?>" class="form-control" required>
                </div>

                <div>
                    <label class="form-label">End (Month/Year)</label>
                    <input type="month" name="end" value="<?php echo htmlspecialchars($endPeriod); ?>" class="form-control" required>
                </div>

                <div id="kpiBox" style="<?php echo $isSameMonth ? '' : 'display:none;'; ?>">
                    <label class="form-label">Select KPI (Same month)</label>
                    <select name="kpi" class="form-select">
                        <option value="ALL" <?php echo ($tableSel==='ALL')?'selected':''; ?>>All KPIs (Selected Month)</option>
                        <?php foreach ($KPI as $t => $cfg): ?>
                            <option value="<?php echo htmlspecialchars($t); ?>" <?php echo ($tableSel===$t)?'selected':''; ?>>
                                <?php echo htmlspecialchars($cfg['title'] . ' — ' . $cfg['meta']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if (!$isSameMonth): ?>
                    <div>
                        <label class="form-label">Select KPI (Range)</label>
                        <select name="kpi" class="form-select" required>
                            <?php foreach ($KPI as $t => $cfg): ?>
                                <option value="<?php echo htmlspecialchars($t); ?>" <?php echo ($tableSel===$t)?'selected':''; ?>>
                                    <?php echo htmlspecialchars($cfg['title'] . ' — ' . $cfg['meta']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>

                <div class="ms-auto d-flex gap-2">
                    <button class="btn btn-success btn-ghost" name="submit" value="1">
                        <i class="bi bi-search"></i> Show Results
                    </button>

                    <button class="btn btn-outline-secondary btn-ghost" name="download" value="csv">
                        <i class="bi bi-download"></i> Download CSV
                    </button>
                </div>

            </form>
        </div>
    </div>

    <!-- Results -->
    <div class="card section-card mb-3">
        <div class="section-top">
            <h2 class="section-title">
                <i class="bi bi-table text-success"></i>
                Results
            </h2>
            <div class="section-sub">
                Showing newest records first.
            </div>
        </div>

        <div class="card-body">

            <?php if ($errorMsg): ?>
                <div class="alert alert-danger rounded-4">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php echo $errorMsg; ?>
                </div>

            <?php elseif (empty($data)): ?>
                <div class="alert alert-warning rounded-4">
                    <i class="bi bi-info-circle-fill"></i>
                    No records found for the selected period.
                </div>

            <?php else: ?>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <?php if ($isSameMonth && $tableSel === 'ALL'): ?>
                                    <th>KPI</th>
                                    <th>Company/Unit</th>
                                <?php endif; ?>
                                <th>Year</th>
                                <th>Month</th>
                                <th class="text-end">Value</th>
                                <th>Entered By</th>
                                <th>Date Entered</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data as $r): ?>
                                <tr>
                                    <?php if ($isSameMonth && $tableSel === 'ALL'): ?>
                                        <td>
                                            <span class="kpi-chip">
                                                <i class="bi bi-clipboard-data"></i>
                                                <?php echo htmlspecialchars($r['kpi_title']); ?>
                                            </span>
                                        </td>
                                        <td class="text-muted fw-semibold">
                                            <?php echo htmlspecialchars($r['kpi_meta'] . " | " . $r['kpi_unit']); ?>
                                        </td>
                                    <?php endif; ?>

                                    <td><?php echo htmlspecialchars($r['report_year']); ?></td>
                                    <td><?php echo htmlspecialchars($r['report_month']); ?></td>

                                    <td class="text-end fw-bold">
                                        <?php
                                        $val = isset($r['kpi_value']) ? (float)$r['kpi_value'] : 0.0;
                                        echo number_format($val, 2);
                                        ?>
                                    </td>

                                    <td><?php echo htmlspecialchars($r['created_by'] ?? ''); ?></td>
                                    <td><?php echo isset($r['created_at']) ? date('Y-m-d', strtotime($r['created_at'])) : ''; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- TOTALS -->
                <div class="mt-3 total-card">
                    <div class="total-left">
                        <div class="total-icon"><i class="bi bi-calculator"></i></div>
                        <div>
                            <div class="total-title"><?php echo htmlspecialchars($totalLabel); ?></div>
                            <div class="total-sub">
                                Period: <?php echo htmlspecialchars($startPeriod); ?> to <?php echo htmlspecialchars($endPeriod); ?>
                            </div>
                        </div>
                    </div>
                    <div class="total-value">
                        <div class="num"><?php echo number_format($totalLitres, 2); ?></div>
                        <div class="unit"><?php echo htmlspecialchars($totalUnit); ?></div>
                    </div>
                </div>

            <?php endif; ?>

        </div>
    </div>

    <!-- CHART -->
    <?php if (!$errorMsg && !empty($data) && !empty($chartLabels)): ?>
    <div class="card section-card">
        <div class="section-top">
            <h2 class="section-title">
                <i class="bi bi-graph-up-arrow text-primary"></i>
                Trend Graph
            </h2>
            <div class="section-sub">
                Month vs Consumption (sum of values per month).
            </div>
        </div>

        <div class="card-body">
            <div class="chart-wrap">
                <div class="chart-head">
                    <div>
                        <div class="chart-title">Monthly Consumption Trend</div>
                        <div class="chart-note">
                            <?php
                                if ($isSameMonth && $tableSel === 'ALL') {
                                    echo "Selected Month (All KPIs) — aggregated values";
                                } elseif (isset($KPI[$tableSel])) {
                                    echo htmlspecialchars($KPI[$tableSel]['title'] . " — " . $KPI[$tableSel]['meta']);
                                } else {
                                    echo "Selected KPI";
                                }
                            ?>
                        </div>
                    </div>
                    <div class="text-muted fw-semibold">
                        Unit: <?php echo htmlspecialchars($totalUnit); ?>
                    </div>
                </div>

                <canvas id="trendChart" height="90"></canvas>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>

<script>
(function(){
    const start = document.querySelector('input[name="start"]');
    const end   = document.querySelector('input[name="end"]');
    const kpiBox = document.getElementById('kpiBox');

    function toggleKpiBox(){
        if (!start.value || !end.value) return;
        kpiBox.style.display = (start.value === end.value) ? '' : 'none';
    }

    start.addEventListener('change', toggleKpiBox);
    end.addEventListener('change', toggleKpiBox);
    toggleKpiBox();
})();
</script>

<?php if (!$errorMsg && !empty($data) && !empty($chartLabels)): ?>
<script>
(function(){
    const labels = <?php echo json_encode($chartLabels, JSON_UNESCAPED_SLASHES); ?>;
    const values = <?php echo json_encode($chartValues, JSON_UNESCAPED_SLASHES); ?>;

    // Convert YYYY-MM to nicer label (e.g., 2025-01 -> Jan 2025)
    const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const prettyLabels = labels.map(k => {
        const [y, m] = k.split("-");
        const mi = parseInt(m, 10) - 1;
        return (monthNames[mi] || m) + " " + y;
    });

    const ctx = document.getElementById('trendChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: prettyLabels,
            datasets: [{
                label: 'Consumption',
                data: values,
                tension: 0.35,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6,
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: true },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const v = Number(context.parsed.y || 0);
                            return " " + v.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2});
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { maxRotation: 0, autoSkip: true }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value){
                            return Number(value).toLocaleString();
                        }
                    }
                }
            }
        }
    });
})();
</script>
<?php endif; ?>

</body>
</html>
